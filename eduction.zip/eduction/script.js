
function runCode() {
    alert("Backend setup zaroori hai code run karne ke liye. (Python/C++/Java)");
}